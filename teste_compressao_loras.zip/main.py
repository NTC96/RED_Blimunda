# formato: aaa.aa aaa.aa aaa.aa gg.gggggg gg.gggggg hhhh.hh vvvv.v rrrr.r rrrr.r rrrr.r ttttt
# Como interpretar? a= aceleracao (em cada eixo), g= gps (lat e long), h= altitude, v= velocidade
#                   r = rotacao (em cada eixo) t=tempo
# Os dados podem ter o numero de casas decimais que se quiser, mas a partir das casas decimais acima representadas
# serao ignoradas
# Os dados não podem exceder o numero de algarismos inteiros (à esquerda da virgula). O sinal - conta como um algarismo
# Por exemplo -34.4542 123.1 são dados validos para aceleracoes. 231230 é um dado inválido para o tempo.

from compressao_dados import *
acc=[0,0,0]
rot=[0,0,0]
gps=[0,0]

with open('dados.txt', 'r') as f:
    for line in f:
        acc[0], acc[1], acc[2], gps[0], gps[1], alt, v, rot[0], rot[1], rot[2], t = [float(i) for i in line.split()]

        s = comprime_dados(acc, gps, alt, v, rot, t)
        print(s)
        print()
        #print(len(s.encode('utf-8')))
        s = descomprime_dados(s)
        print(s)

